@extends('template.main')
@section('content')
    <ol>
        @foreach ($studentList as $data)
        <li>
            {{ $data->name }} | {{ $data->gender }} | {{ $data->nis }}
        </li>
        @endforeach
    </ol>
@stop